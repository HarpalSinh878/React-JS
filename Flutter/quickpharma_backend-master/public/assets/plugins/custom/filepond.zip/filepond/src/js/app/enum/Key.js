export const Key = {
    ENTER: 13,
    SPACE: 32
};
