export const isString = value => typeof value === 'string';
